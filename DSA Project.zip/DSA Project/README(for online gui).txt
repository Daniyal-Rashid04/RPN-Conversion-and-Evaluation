RPN EXPRESSION PROJECT

This project is a calculator program built in C++ that handles Infix,
Prefix, and Postfix. It uses a Python Flask setup to show
the results on a web browser instead of a black terminal.

--- [ 1. SETUP & RUNNING ] --------------------------------

The project is not hosted online. You must run it locally
on your machine.

1. Make sure you have Python 3 installed.
2. Open your terminal/cmd in the project folder.
3. Install the web library by typing:
pip install flask
4. If you have it, Open the "Online GUI" folder
and run the "RUN_PROGRAM.bat" file.


--- [ 2. HOW TO USE ] -------------------------------------

* CONVERSION: Put in any math expression. The engine
shows you the Infix, Postfix, and Prefix versions.
* EVALUATION: If the math is valid, the program
calculates the final answer.

--- [ 3. IMPORTANT RULES ] --------------------------------

If you dont follow these rules, the engine will return an ERROR:

* MUST USE SPACES: The parser splits tokens by spaces.
RIGHT: ( 10 + 5 ) * 2
WRONG: (10+5)*2
* NEGATIVE NUMBERS: Put the minus right against the number.
Example: -5 + 10
* BRACKETS: You can use (), [], or {}. The code handles
all of them the same way.
* OPERATORS: Works with + , - , * , / , ^ (power) , and % (mod).

--- [ 4. HOW IT WORKS ] -----------------------------------

The core logic is in C++ (ExpressionEngine class). We used
the Shunting-Yard algorithm with a stack to move operators
around based on PEMDAS rules.

The Python part is just a bridge to take the input from
the website and send it to the C++ code to get the answer.

--- [ 5. ERROR HANDLING ] ---------------------------------

* Division by zero shows "Undefined".
* Mismatched brackets will show a specific error message.
* Typing letters or junk will trigger the "Invalid Token"
filter in the C++ engine.

--- [ 6. SOURCE CODE ] ------------------------------------

Everything is documented and uploaded on Github:
[https://github.com/muneebhaider9363-ui/RPN-Program](https://github.com/muneebhaider9363-ui/RPN-Program)

===========================================================

